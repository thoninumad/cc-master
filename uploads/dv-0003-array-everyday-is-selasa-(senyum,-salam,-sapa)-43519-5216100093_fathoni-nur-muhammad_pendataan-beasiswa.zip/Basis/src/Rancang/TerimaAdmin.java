/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Rancang;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


/**
 *
 * @author ACER
 */
public class TerimaAdmin extends javax.swing.JFrame {

    DefaultTableModel tabelModel;
    LinkedList<DataTerima> mylinkedlist = new LinkedList<DataTerima>();
    
    private int tunjuk;
    /**
     * Creates new form TerimaAdmin
     */
    public TerimaAdmin() {
        initComponents();
        loadData();
        tampildata(0);
        tampilDataTabel();
        lebarKolom();
        tabel();
    }
    
     public void lebarKolom(){ 
        TableColumn column;
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF); 
        column = jTable2.getColumnModel().getColumn(0); 
        column.setPreferredWidth(100);
        column = jTable2.getColumnModel().getColumn(1); 
        column.setPreferredWidth(258); 
        column = jTable2.getColumnModel().getColumn(2); 
        column.setPreferredWidth(100); 
        column = jTable2.getColumnModel().getColumn(3); 
        column.setPreferredWidth(90); 
    }
    
    void hapus_text(){
        txtNrp.setText("");
        txtMahasiswa.setText("");
        txtId.setText("");
        buttonGroup1.clearSelection();
    }
  
    void enabled(){
        txtNrp.setEnabled(true);
        txtMahasiswa.setEnabled(true);
        txtId.setEnabled(true);
        txtNrp.requestFocus();
        jRadioButton1.setEnabled(true);
        jRadioButton2.setEnabled(true);
    }
    
    void desabled(){
        txtNrp.setEnabled(false);
        txtMahasiswa.setEnabled(false);
        txtId.setEnabled(false);
        jRadioButton1.setEnabled(false);
        jRadioButton2.setEnabled(false);
    }
    
     public void baru(){
        txtNrp.setEditable(true);
        txtMahasiswa.setEditable(true);
        txtId.setEditable(true);
        jSave.setEnabled(true);
        jReset.setEnabled(true);
        jBaru.setEnabled(false);
        jHapus.setEnabled(false);
        jEdit.setEnabled(false);
    }
     
     public void kondisiSimpan(){
        jBaru.setEnabled(false);
        jEdit.setEnabled(false);
        jHapus.setEnabled(false);
    }
     
    public void tampilStatus() {
        int row = jTable2.getSelectedRow();
        String status = jTable2.getValueAt(row, 3).toString();
        if (status.equals("Aktif")) {
            jRadioButton1.setSelected(true);
        } else {
            jRadioButton2.setSelected(true);
        }
    }
     
    public void saveData() {
        try {

            FileOutputStream fout = new FileOutputStream("DataTerima.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(mylinkedlist);
            oos.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void loadData() {
        try {
            FileInputStream fileIn = new FileInputStream("DataTerima.dat");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            LinkedList<DataTerima> tmp = (LinkedList<DataTerima>) in.readObject();

            mylinkedlist.clear();
            mylinkedlist.addAll(tmp);

            in.close();
            fileIn.close();

        } catch (IOException i) {
            i.printStackTrace();
            return;
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
            return;
        }
    }
    
    public void tampilDataTabel() {
        String[] kolom = {"NRP", "Nama Mahasiswa", "ID Beasiswa", "Status"};
        Object[][] objDataTerima = new Object[mylinkedlist.size()][4];
        int i = 0;
        for (DataTerima n : mylinkedlist) {
            String[] arrDataTerima = {n.getNrp(), n.getMahasiswa(), n.getId(), n.getStatus()};
            objDataTerima[i] = arrDataTerima;
            i++;
        }
        tabelModel = new DefaultTableModel(objDataTerima, kolom) {
            public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
            }
        };
        jTable2.setModel(tabelModel);
    }
    
     private void setdata() {
        DataTerima a;
        a = mylinkedlist.get(tunjuk);
        txtNrp.setText(a.getNrp());
        txtMahasiswa.setText(a.getMahasiswa());
        txtId.setText(a.getId());
        
        txtId.setEditable(false);
        txtMahasiswa.setEditable(false);
        txtNrp.setEditable(false);
    }
     
     private void tampildata(int indeks) {
        
        tunjuk = indeks;
        if (mylinkedlist.isEmpty()) {
            return;
        }
        setdata();
    }
     
    private void tabel() {
        jTable2.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                int baris = jTable2.getSelectedRow();

                if (baris != -1) {
                    tampildata(baris);
                }
            }
        });
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jNrp = new javax.swing.JLabel();
        jMahasiswa = new javax.swing.JLabel();
        jID = new javax.swing.JLabel();
        jStatus = new javax.swing.JLabel();
        txtNrp = new javax.swing.JTextField();
        txtMahasiswa = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jBaru = new javax.swing.JButton();
        jSave = new javax.swing.JButton();
        jEdit = new javax.swing.JButton();
        jReset = new javax.swing.JButton();
        jBatal = new javax.swing.JButton();
        jHapus = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("BASIS  v1.0");

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setPreferredSize(new java.awt.Dimension(984, 95));

        jLabel1.setFont(new java.awt.Font("Perpetua Titling MT", 1, 18)); // NOI18N
        jLabel1.setText("Data Penerima Beasiswa");

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton1.setText("Log out");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton2.setText("Data Beasiswa");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Rancang/siits(2).png"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Rancang/hmsiits(2).png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(226, 226, 226)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addGap(38, 38, 38))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton1))
                        .addGap(30, 30, 30))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Form Data Penerima", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        jNrp.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jNrp.setText("NRP");

        jMahasiswa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jMahasiswa.setText("Nama Mahasiswa");

        jID.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jID.setText("ID Beasiswa*");

        jStatus.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jStatus.setText("Status");

        txtNrp.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtNrp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNrpKeyPressed(evt);
            }
        });

        txtMahasiswa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtMahasiswa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtMahasiswaKeyPressed(evt);
            }
        });

        txtId.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdKeyPressed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioButton1.setText("Aktif");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jRadioButton2.setText("Dicabut");

        jBaru.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jBaru.setText("Baru");
        jBaru.setMaximumSize(new java.awt.Dimension(71, 23));
        jBaru.setMinimumSize(new java.awt.Dimension(71, 23));
        jBaru.setPreferredSize(new java.awt.Dimension(71, 23));
        jBaru.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBaruActionPerformed(evt);
            }
        });

        jSave.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jSave.setText("Simpan");
        jSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveActionPerformed(evt);
            }
        });

        jEdit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jEdit.setText("Ubah");
        jEdit.setMaximumSize(new java.awt.Dimension(71, 23));
        jEdit.setMinimumSize(new java.awt.Dimension(71, 23));
        jEdit.setPreferredSize(new java.awt.Dimension(71, 23));
        jEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEditActionPerformed(evt);
            }
        });

        jReset.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jReset.setText("Reset");
        jReset.setMaximumSize(new java.awt.Dimension(71, 23));
        jReset.setMinimumSize(new java.awt.Dimension(71, 23));
        jReset.setPreferredSize(new java.awt.Dimension(71, 23));
        jReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jResetActionPerformed(evt);
            }
        });

        jBatal.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jBatal.setText("Batal");
        jBatal.setMaximumSize(new java.awt.Dimension(71, 23));
        jBatal.setMinimumSize(new java.awt.Dimension(71, 23));
        jBatal.setPreferredSize(new java.awt.Dimension(71, 23));
        jBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBatalActionPerformed(evt);
            }
        });

        jHapus.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jHapus.setText("Hapus");
        jHapus.setMaximumSize(new java.awt.Dimension(71, 23));
        jHapus.setMinimumSize(new java.awt.Dimension(71, 23));
        jHapus.setPreferredSize(new java.awt.Dimension(71, 23));
        jHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jHapusActionPerformed(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(153, 0, 0));
        jLabel4.setText("*Harap diperhatikan Data Beasiswa mengenai ID Beasiswa");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jMahasiswa)
                    .addComponent(jNrp)
                    .addComponent(jID)
                    .addComponent(jStatus)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jBaru, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jSave))
                    .addComponent(jEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtNrp, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtMahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jRadioButton1)
                            .addGap(27, 27, 27)
                            .addComponent(jRadioButton2)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jHapus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jBatal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)))
                .addGap(39, 39, 39))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(75, 75, 75))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jNrp)
                    .addComponent(txtNrp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jMahasiswa))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jID))
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jStatus)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSave, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBaru, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jReset, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tabel Data Penerima Beasiswa", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1128, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jResetActionPerformed
        // TODO add your handling code here:
        hapus_text();
    }//GEN-LAST:event_jResetActionPerformed

    private void jSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveActionPerformed
        // TODO add your handling code here:
         if(txtNrp.getText().trim().equals("")){
            enabled();
            kondisiSimpan();
            JOptionPane.showMessageDialog(null,"Maaf, NRP belum di isi!");
            txtNrp.requestFocus();
        } else if(txtMahasiswa.getText().trim().equals("")){
            enabled();
            kondisiSimpan();
            JOptionPane.showMessageDialog(null,"Maaf, Nama mahasiswa belum di isi!");
            txtMahasiswa.requestFocus();
        } else  if(txtId.getText().trim().equals("")){
            enabled();
            kondisiSimpan();
            JOptionPane.showMessageDialog(null,"Maaf, ID Beasiswa belum di isi!");
            txtId.requestFocus();
        } else {
            String mahasiswa=txtMahasiswa.getText();
            String nrp=txtNrp.getText();
            String id=txtId.getText();
         
            jRadioButton1.setActionCommand("Aktif");
            jRadioButton2.setActionCommand("Dicabut");
            
            String status=buttonGroup1.getSelection().getActionCommand();
            
            mylinkedlist.add(new DataTerima(nrp, mahasiswa, id, status));
            this.saveData();
            loadData();
            tampilDataTabel();
            lebarKolom();
            tampildata(mylinkedlist.size()-1);
            JOptionPane.showMessageDialog(this, "Save Success");
            jSave.setEnabled(false);
        }
    }//GEN-LAST:event_jSaveActionPerformed

    private void jBaruActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBaruActionPerformed
        // TODO add your handling code here:
        hapus_text();
        enabled();
        baru();
    }//GEN-LAST:event_jBaruActionPerformed

    private void jBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBatalActionPerformed
        // TODO add your handling code here:
        desabled();
        jEdit.setText("Ubah");
        jSave.setEnabled(false);
        jEdit.setEnabled(false);
        jHapus.setEnabled(false);
        jReset.setEnabled(false);
        jBaru.setEnabled(true);
    }//GEN-LAST:event_jBatalActionPerformed

    private void jEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEditActionPerformed
        // TODO add your handling code here:
        if(jEdit.getText().equals("Ubah")){
            enabled();
            jEdit.setText("Simpan");
            jBaru.setEnabled(false);
            jSave.setEnabled(false);
            jHapus.setEnabled(false);
            jReset.setEnabled(false);
            jBatal.setEnabled(true);
            txtNrp.setEditable(true);
            txtMahasiswa.setEditable(true);
            txtId.setEditable(true);
            txtNrp.setText(mylinkedlist.get(tunjuk).getNrp());
            txtMahasiswa.setText(mylinkedlist.get(tunjuk).getMahasiswa());
            txtId.setText(mylinkedlist.get(tunjuk).getId());
            tampilStatus();
        } else if(jEdit.getText().equals("Simpan")) {
            String nrp=txtNrp.getText();
            String mahasiswa=txtMahasiswa.getText();
            String id=txtId.getText();
            
            jRadioButton1.setActionCommand("Aktif");
            jRadioButton2.setActionCommand("Dicabut");
            
            String status=buttonGroup1.getSelection().getActionCommand();
            DataTerima a = mylinkedlist.get(tunjuk);
            a.setNrp(nrp);
            a.setMahasiswa(mahasiswa);
            a.setId(id);
            a.setStatus(status);
            this.saveData();
            loadData();
            tampilDataTabel();
            lebarKolom();
            tampildata(tunjuk);
            JOptionPane.showMessageDialog(this, "Edit Success");
        }
    }//GEN-LAST:event_jEditActionPerformed

    private void jHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jHapusActionPerformed
        // TODO add your handling code here:
        mylinkedlist.remove(tunjuk);
        this.saveData();
        loadData();
        tampilDataTabel();
        lebarKolom();
        tampildata(0);
        JOptionPane.showMessageDialog(this, "Delete Success");
    }//GEN-LAST:event_jHapusActionPerformed

    private void txtMahasiswaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMahasiswaKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            txtId.requestFocus();
        }
    }//GEN-LAST:event_txtMahasiswaKeyPressed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        enabled();
        jEdit.setEnabled(true);
        jEdit.setText("Ubah");
        jHapus.setEnabled(true);
        jBaru.setEnabled(true);
        txtId.setEditable(false);
        txtNrp.setEditable(false);
        txtMahasiswa.setEditable(false);
        txtId.setEditable(false);
        tampilStatus();
    }//GEN-LAST:event_jTable2MouseClicked

    private void txtNrpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNrpKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            txtMahasiswa.requestFocus();
        }
    }//GEN-LAST:event_txtNrpKeyPressed

    private void txtIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            jRadioButton1.requestFocus();
        }
    }//GEN-LAST:event_txtIdKeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new Mains().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new BeasiswaAdmin().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TerimaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TerimaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TerimaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TerimaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TerimaAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jBaru;
    private javax.swing.JButton jBatal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jEdit;
    private javax.swing.JButton jHapus;
    private javax.swing.JLabel jID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jMahasiswa;
    private javax.swing.JLabel jNrp;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JButton jReset;
    private javax.swing.JButton jSave;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jStatus;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMahasiswa;
    private javax.swing.JTextField txtNrp;
    // End of variables declaration//GEN-END:variables
}

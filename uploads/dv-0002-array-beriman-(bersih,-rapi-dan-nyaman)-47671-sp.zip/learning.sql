-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Sep 2019 pada 14.51
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learning`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('Garuda', '12345');

-- --------------------------------------------------------

--
-- Struktur dari tabel `materi`
--

CREATE TABLE `materi` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `jmlSoal` int(11) NOT NULL,
  `link_video` varchar(50) NOT NULL,
  `pdf` varchar(100) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `tipe` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `materi`
--

INSERT INTO `materi` (`id`, `judul`, `jmlSoal`, `link_video`, `pdf`, `gambar`, `tipe`) VALUES
(1, 'Innovation', 5, 'https://www.youtube.com/embed/IiyMkOfycOg', '08324846.pdf', 'no-image.png', 'video/mp4'),
(2, 'Sincerity', 5, '4-AGILITY.mp4', '08324846.pdf', 'no-image.png', 'video/mp4'),
(3, 'Synergy', 3, '1-SYNERGY.mp4', '', 'no-image.png', 'video/mp4'),
(4, 'CustomerFocus', 7, '3-CUSTOMER FOCUS.mp4', '', 'no-image.png', 'video/mp4');

-- --------------------------------------------------------

--
-- Struktur dari tabel `quiz`
--

CREATE TABLE `quiz` (
  `idq` int(11) NOT NULL,
  `id_quiz` varchar(10) NOT NULL,
  `id_materi` int(10) NOT NULL,
  `soal` varchar(200) NOT NULL,
  `jwba` varchar(100) NOT NULL,
  `jwbb` varchar(100) NOT NULL,
  `jwbc` varchar(100) NOT NULL,
  `jwbd` varchar(100) NOT NULL,
  `jwbBenar` varchar(100) NOT NULL,
  `fotoSoal` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `quiz`
--

INSERT INTO `quiz` (`idq`, `id_quiz`, `id_materi`, `soal`, `jwba`, `jwbb`, `jwbc`, `jwbd`, `jwbBenar`, `fotoSoal`) VALUES
(1, '1', 1, 'Ini soal 1 materi 1', '1', '2', '3', '4', '1', 'bg_main.jpg'),
(2, '1', 2, 'yang bukan merupakan aspek SINCERITY', 'Honesty', 'Synergy', 'safety', 'Agility', 'Honesty', ''),
(3, '2', 1, 'qwerty', 'xasa', 'zazs', 'qweq', 'asdasd', 'asdasd', ''),
(4, '2', 2, 'Berikut merupakan perilaku utama dari nilai Safety', 'Collaborate', 'Honesty', 'Compliance', 'Persistent', 'Compliance', ''),
(5, '3', 2, 'Berikut ini yang bukan merupakan perilaku utama dari Sincerity', 'Collaborate', 'Innovative', 'Care & Polite', 'Risk Management', 'Innovative', ''),
(6, '3', 1, 'Kamu', 'Siapa', 'Dia', 'Cantik', 'Ganteng', 'Ganteng', ''),
(7, '4', 2, 'Berikut merupakan contoh perilaku yang paling tepat dari values Customer Focus adalah', 'Menjaga rahasia perusahaan', 'mengelola resiko dari setiap keputusan yang akan diambil', 'bekerjasama dengan unit lain untuk menyelesaikan permasalahan', 'menyelesaikan masalah yang dihadapi penumpang dengan cepat', 'menyelesaikan masalah yang dihadapi penumpang dengan cepat', ''),
(8, '4', 1, 'HAHAHA', 'HA', 'HI', 'HU', 'HE', 'HA', ''),
(9, '5', 1, 'HEHEHEHE', 'HA', 'HE', 'HU', 'HO', 'HE', ''),
(10, '5', 2, 'Empower Diversity merupakan perilaku utama dari?', 'Synergy', 'Customer Focus', 'Safety', 'Integrity', 'Synergy', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `nopeg` varchar(11) NOT NULL,
  `nama_panggilan` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `picture` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `skor` int(11) NOT NULL,
  `skorawal` int(11) NOT NULL,
  `rank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`nopeg`, `nama_panggilan`, `nama_lengkap`, `unit`, `picture`, `password`, `skor`, `skorawal`, `rank`) VALUES
('123', 'test', 'test', 'Test', 'profile-picture.png', '123', 30, 0, 1),
('1234567890', 'R', 'R', 'JKT', 'no-picture.png', 'R', 10, 0, 0),
('14', 'Anonim', 'Anonymous', 'JKTID', 'admin.jpg', 'qwerty', 555, 0, 0),
('16', '16', '', '16', '', '16', 16, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`idq`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nopeg`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `materi`
--
ALTER TABLE `materi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `quiz`
--
ALTER TABLE `quiz`
  MODIFY `idq` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

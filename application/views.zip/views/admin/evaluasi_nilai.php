<?php
session_start();
include('connection/conn.php');
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Bank Jatim | Dashboard</title>
    <link rel="icon" type="image/png" href="<?php echo base_url()?>assets/gi.ico">
    <link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url()?>css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url()?>css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url()?>css/style.css" rel="stylesheet">

</head>

<body>
    <div id="wrapper">
       <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="<?php echo base_url()?>img/profile_small.jpg" />
                             </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $this->session->userdata('username')?></strong>
                             </span> <span class="text-muted text-xs block">Admin <b class="caret"></b></span> </span> </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="<?php echo base_url()?>admin/logout">Logout</a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            GI
                        </div>
                    </li>
                    <li class="active">
                        <a href="<?php echo base_url()?>admin/index"><i class="fa fa-th-large"></i> <span class="nav-label"> Dashboard Utama</span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="<?php echo base_url()?>admin/index"><i class="fa fa-th-large"></i> <span class="nav-label"> Dashboard Utama</span></a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_indexP"><i class="	fa fa-line-chart"></i> Dashboard Index Pencapaian</a></li>
                            <li class="active"><a href="<?php echo base_url()?>admin/dashboard_topEx"><i class="	fa fa-line-chart"></i> Dashboard Top Execution</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_botEx"><i class="	fa fa-line-chart"></i> Dashboard Bottom Execution</a></li>
                        </ul>
                    </li>
                    <li >
                        <a href="<?php echo base_url()?>admin/dashboard_dir"><i class="fa fa-dashboard"></i> <span class="nav-label"> Dashboard Direktorat</span></a>
                    </li>
                    <li >
                        <a href=""><i class="	fa fa-area-chart"></i> <span class="nav-label"> Dashboard Cabang</span><span class="fa fa-caret-down pull-right"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="<?php echo base_url()?>admin/dashboard_cb_utama"><i class="fa fa-area-chart"></i> Dashboard Cabang Utama</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_cb_pembantu"><i class="fa fa-area-chart"></i> Dashboard Cabang Pembantu</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_k_kas"><i class="fa fa-area-chart"></i> Dashboard Kantor Kas</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_cb_syariah"><i class="fa fa-area-chart"></i> Dashboard Cabang Utama Syariah</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_cb_pembantusy"><i class="fa fa-area-chart"></i> Dashboard Cabang Pembantu Syariah</a></li>
                        </ul>
                    </li>
                    <li >
                        <a href=""><i class="	fa fa-puzzle-piece"></i> <span class="nav-label">Culture Team</span><span class="fa fa-caret-down pull-right"></span></a>
                        <ul class="nav nav-second-level">
                            <li ><a href="<?php echo base_url()?>admin/team_overall"><i class="fa fa-rocket"></i> Team Overall</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_warrior"><i class="fa fa-calendar"></i> Dashboard Warrior</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_implementasi_budaya"><i class="fa fa-bar-chart-o"></i> Dashboard TIB</a></li>
                            <li><a href="<?php echo base_url()?>admin/dashboard_booster"><i class="fa fa-pencil"></i> Dashboard Booster</a></li>
                        </ul>
                    </li>
                    <li >
                        <a href="<?php echo base_url()?>admin/team_overall"><i class="	fa fa-puzzle-piece"></i> <span class="nav-label">Culture Team</span></a>
                    </li>
                    <li >
                        <a href=""><i class="	fa fa-users"></i> <span class="nav-label">User dan Pendaftaran</span><span class="fa fa-caret-down pull-right"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="<?php echo base_url()?>admin/daftar_user"><i class="fa fa-user-plus"></i> Daftar User</a></li>
                            <li><a href="<?php echo base_url()?>admin/daftar_warrior"><i class="	fa fa-user-secret"></i> Daftar Culture Agent</a></li>
                            <li><a href="<?php echo base_url()?>admin/daftar_tib"><i class="	fa fa-shield"></i> Daftar TIB</a></li>
                            <li><a href="<?php echo base_url()?>admin/daftar_booster"><i class="	fa fa-paper-plane"></i> Daftar Booster</a></li>
                        </ul>
                    </li>
                </ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
          <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
              <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>

          </div>
              <ul class="nav navbar-top-links navbar-right">
                  <li>
                      <span class="m-r-sm text-muted welcome-message">Welcome to Culture Program</span>
                  </li>
                  <li>
                      <a href="<?php echo base_url()?>admin/logout">
                          <i class="fa fa-sign-out"></i> Log out
                      </a>
                  </li>
              </ul>
          </nav>
        </div>

            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-9">
                    <h2>Score Management</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url()?>admin">Home</a>
                        </li>
                        <li class="active">
                            <strong>Evaluate Scoring</strong>
                        </li>
                    </ol>
                </div>
            </div>

        <div class="wrapper wrapper-content animated fadeInRight">
        

            <div class="row wrapper white-bg page-heading" style="padding-top:20px">

                <div class="col-lg-12">
                <!-- <div class="ibox float-e-margins"> -->
                    <!-- <div class="ibox-title">
                        <h5>Daftar Program</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div> -->
                    <!-- <div class="ibox-content"> -->

                  <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped table-hover dataTables-example">
                      <thead>
                        <tr class="headings">
                          <th class="text-center" style="width:3%">No</th>
                          <th class="text-center" style="width:35%">Program</th>
                            <th class="text-center" style="width:12%">Unit</th>
                          <th class="text-center" style="width:12%">Score</th>
                            <th class="text-center" style="width:12%">Target</th>
                          <th class="text-center" style="width:14%">Input Date</th>
                          <th class="text-center" style="width:11%">Action</th>
                        </tr>
                      </thead>
                <tbody class="text-center">
                  <?php $a=count($nilai);  $b=0; for ($i=0; $i < $a; $i++) { $b++; ?>
                  <tr>
                  <td style="width:3%"><?php echo $b?></td>
                  <td style="width:35%"><?php echo $nilai[$i]->input_detail_c?></td>
                      <td style="width:12%"><?php echo $nilai[$i]->input_user_c?></td>
                  <td style="width:12%"><?php echo $nilai[$i]->input_realisasi?></td>
                  <td style="width:12%"><?php echo $nilai[$i]->	input_target?></td>
                  <td style="width:14%"><?php echo $nilai[$i]->last_modified_c?></td>
                  <td style="width:11%" class="text-center">
                                        <button type="button" class="btn btn-warning btn-xs table-hover" data-toggle="modal"  data-target="#evaluate<?php echo $nilai[$i]->input_id?>">Evaluate</button>
                  </td>
                </tr>
                                                        <!-- Modal -->
                                                    <div class="modal fade" id="evaluate<?php echo $nilai[$i]->input_id?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                      <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                          <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title" id="myModalLabel">Evaluate Scoring</h4>
                                                          </div>
                                                          <div class="modal-body">
                                                                <!-- Isi Modal -->
                                                                <div class="box-body">
                                                                <?php echo form_open_multipart('admin/evaluate_scoring')?>
                                                                <div class="row">
                                                                  <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Nama Program</h5>
                                                                        <input type="hidden" class="form-control" readonly name="id" autocomplete="off" required value="<?php echo $nilai[$i]->input_id ?>">
                                                                      <input type="text" class="form-control" readonly name="program" autocomplete="off" required value="<?php echo $nilai[$i]->input_detail_c?>">
                                                                    </div>
                                                                  </div>
                                                                    <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Unit</h5>
                                                                      <input type="text" class="form-control" readonly name="unit" autocomplete="off" required value="<?php echo $nilai[$i]->input_user_c?>">
                                                                    </div>
                                                                  </div>
                                                                  <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Target Score</h5>
                                                                      <input type="text" class="form-control" readonly name="target" autocomplete="off" required value="<?php echo $nilai[$i]->input_target?>">
                                                                        <input type="hidden" class="form-control" readonly name="unit" autocomplete="off" required value="<?php echo $nilai[$i]->input_user_c?>">
                                                                        <?php
                                                                          $n=1;
                                                                          $queries=mysqli_query($con,"select * from total_score where kode_unit='". $nilai[$i]->input_user_c. "'");
                                                                          while ($row=mysqli_fetch_array($queries)) { ?>
                                                                        <?php if ($row['kode_unit']==null&&empty($row['kode_unit'])) { ?>
                                                                            <?php echo 'kosong'; } else{?>
                                                                                <input type="hidden" class="form-control" name="bobot3" autocomplete="off" value="<?php echo round($row['nilai_bobot3']) ?>">
                                                                                <input type="hidden" class="form-control" name="bobot4" autocomplete="off" value="<?php echo round($row['nilai_bobot4']) ?>">
                                                                                <input type="hidden" class="form-control" name="bobot5" autocomplete="off" value="<?php echo round($row['nilai_bobot5']) ?>">
                                                                                <input type="hidden" class="form-control" name="bobot6" autocomplete="off" value="<?php echo round($row['nilai_bobot6']) ?>">
                                                                        <?php } } ?>
                                                                    </div>
                                                                  </div>
                                                                  <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Evaluate Score</h5>
                                                                      <input type="text" class="form-control" name="score" autocomplete="off" required value="<?php echo $nilai[$i]->input_realisasi?>">
                                                                    </div>
                                                                  </div>
                                                                  <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Feedback</h5>
                                                                      <textarea class="form-control" rows="5" name="feedback" autocomplete="off" required></textarea>
                                                                    </div>
                                                                  </div>
                                                                  <div class="col-md-12">
                                                                    <div class="form-group">
                                                                      <h5>Download Evidence</h5>
                                                                      <a href="<?php echo base_url()?>/uploads/<?php echo $nilai[$i]->input_attach ?>" class="btn btn-primary" download><i class="fa fa-download" style="color:white"></i>  Download Evidence</a>
                                                                    </div>
                                                                  </div>
                                                                     <div class="col-md-12">
                                                                    <div class="form-group">
                                                                    <div class="checkbox">
                                                                      <label><input type="checkbox" name="nlbobot4" value="4">Tracking Method berjalan (view evidence)</label>
                                                                    </div>
                                                                    <div class="checkbox">
                                                                      <label><input type="checkbox" name="nlbobot5" value="5">Enforcement Positif Method berjalan (view evidence)</label>
                                                                    </div>
                                                                    <div class="checkbox disabled">
                                                                      <label><input type="checkbox" name="nlbobot6" value="6" >Enforcement Negatif Method berjalan (view evidence)</label>
                                                                    </div>
                                                                         </div></div>    
                                                                   
                                                                <div class="modal-footer">
                                                                    <button class="btn btn-success" type="submit"><i class="fa fa-paper-plane "></i>  Submit</button>
                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                                </div>
                                                                <?php echo form_close()?>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>            
                                        </div>
                                            <?php } ?>
                                            </tbody>
                                          </table>
                                    </div>

                    </div>
                </div>
                <div class="footer">
                  <div class="row">

                      <div class="footer">
                          <div>
                              <strong>Copyright</strong> &copy; 2019 Bank Jatim. All rights reserved.
                          </div>
                      </div>
                </div>
                </div>

            </div>
        </div>




<!-- Mainly scripts -->
    <script src="<?php echo base_url();?>js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo base_url();?>js/plugins/jeditable/jquery.jeditable.js"></script>

    <script src="<?php echo base_url();?>js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url();?>js/inspinia.js"></script>
    <script src="<?php echo base_url();?>js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    {extend: 'csv'},
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

        });
    </script>


</body>
</html>

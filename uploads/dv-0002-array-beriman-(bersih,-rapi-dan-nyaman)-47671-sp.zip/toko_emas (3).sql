-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Sep 2019 pada 14.51
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_emas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `harga_partai`
--

CREATE TABLE `harga_partai` (
  `id` bigint(100) NOT NULL,
  `warnakrum` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `harga_partai`
--

INSERT INTO `harga_partai` (`id`, `warnakrum`, `harga`) VALUES
(6, 'Krum Putih', 4000),
(7, 'Krum Kuning', 3000),
(8, 'Krum Merah Surabaya', 4000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `harga_satuan`
--

CREATE TABLE `harga_satuan` (
  `id` bigint(100) NOT NULL,
  `kategori` bigint(100) NOT NULL,
  `gambar` text NOT NULL,
  `keterangan` text NOT NULL,
  `putih` int(11) NOT NULL,
  `kuning` int(11) NOT NULL,
  `merahsurabaya` int(11) NOT NULL,
  `merahswasa` int(11) NOT NULL,
  `rosegold` int(11) NOT NULL,
  `hitam` int(11) NOT NULL,
  `doff` int(11) NOT NULL,
  `dimensi2` int(11) NOT NULL,
  `dimensi3` int(11) NOT NULL,
  `dimensi4` int(11) NOT NULL,
  `berlian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `harga_satuan`
--

INSERT INTO `harga_satuan` (`id`, `kategori`, `gambar`, `keterangan`, `putih`, `kuning`, `merahsurabaya`, `merahswasa`, `rosegold`, `hitam`, `doff`, `dimensi2`, `dimensi3`, `dimensi4`, `berlian`) VALUES
(1, 1, '33115-capture.jpg', 'Lebar   : 3.51 - 4.0 cm', 50000, 45000, 45000, 45000, 50000, 0, 5000, 5000, 5000, 5000, 60000),
(2, 1, '27836-s.jpg', 'Lebar   : 3.1 - 3.5 cm', 45000, 40000, 40000, 40000, 45000, 0, 5000, 5000, 5000, 5000, 50000),
(3, 2, '11600-er.jpg', '-', 20000, 15000, 15000, 15000, 20000, 0, 5000, 5000, 5000, 5000, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_bahan`
--

CREATE TABLE `jenis_bahan` (
  `id` int(11) NOT NULL,
  `nama_bahan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_bahan`
--

INSERT INTO `jenis_bahan` (`id`, `nama_bahan`) VALUES
(1, 'Emas'),
(2, 'Perak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_satuan`
--

CREATE TABLE `kategori_satuan` (
  `id` bigint(110) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL DEFAULT '5000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori_satuan`
--

INSERT INTO `kategori_satuan` (`id`, `kategori`, `harga`) VALUES
(1, 'Cincin Cowok', 5000),
(2, 'Cincin Bayi', 5000),
(3, 'Cincin Kawin', 5000),
(4, 'Liontin', 5000),
(5, 'Mainan Nama', 5000),
(6, 'Gelang Kaku', 5000),
(7, 'Gelang Rantai', 5000),
(8, 'Gelang Kaki', 5000),
(9, 'Kalung', 5000),
(10, 'Anting', 5000),
(11, 'Sisik Naga', 5000),
(12, 'Pin Bross', 5000),
(13, 'Jenis Lain', 5000),
(14, 'Cincin Cewek', 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_susutan`
--

CREATE TABLE `laporan_susutan` (
  `po_kode` varchar(100) NOT NULL,
  `berat_stlhcuci` int(11) NOT NULL,
  `berat_stlhcrum` int(11) NOT NULL,
  `berat_retur` int(11) NOT NULL,
  `berat_brghlg` int(11) NOT NULL,
  `berat_susutan` int(11) NOT NULL,
  `jumlah_retur` int(11) NOT NULL,
  `jumlah_brghlg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `laporan_susutan`
--

INSERT INTO `laporan_susutan` (`po_kode`, `berat_stlhcuci`, `berat_stlhcrum`, `berat_retur`, `berat_brghlg`, `berat_susutan`, `jumlah_retur`, `jumlah_brghlg`) VALUES
('1002-2019-PO-SATUAN', 157, 155, 2, 5, 3, 1, 1),
('1001-2019-PO-KRUM', 31, 30, 5, 1, 12, 1, 1),
('1002-2019-PO-KRUM', 0, 0, 0, 0, 0, 0, 0),
('1006-2019-PO-KRUM', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasicabang`
--

CREATE TABLE `lokasicabang` (
  `id` bigint(110) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `notelp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `lokasicabang`
--

INSERT INTO `lokasicabang` (`id`, `nama`, `alamat`, `notelp`) VALUES
(2, 'Surya Sumatera Cabang Sikambing', 'Jl. Sikambing No. 35 B Medan', '06188813114');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pop_data`
--

CREATE TABLE `pop_data` (
  `pop_id` varchar(255) NOT NULL,
  `pop_num` int(11) NOT NULL,
  `pop_customer` varchar(50) NOT NULL,
  `pop_nama` varchar(255) NOT NULL,
  `pop_notelp` varchar(100) NOT NULL,
  `pop_kota` varchar(255) NOT NULL,
  `pop_tglmsk` date NOT NULL,
  `pop_jam` varchar(100) NOT NULL,
  `pop_jamsiap` varchar(100) NOT NULL,
  `pop_tglsls` date NOT NULL,
  `total_berat` int(11) NOT NULL DEFAULT '0',
  `total_harga` int(11) NOT NULL DEFAULT '0',
  `pop_cabang` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `pop_diskon` int(11) NOT NULL DEFAULT '0',
  `pop_voucher` int(11) NOT NULL DEFAULT '0',
  `pop_keterangan` text NOT NULL,
  `pop_bahan` varchar(255) NOT NULL,
  `pop_beratawal` int(11) NOT NULL DEFAULT '0',
  `pop_qty` int(11) NOT NULL,
  `krum` varchar(100) NOT NULL,
  `enamel` varchar(100) NOT NULL,
  `po_CZwarnatepper` varchar(100) NOT NULL,
  `po_keadaan` varchar(100) NOT NULL,
  `po_batukruman` varchar(100) NOT NULL,
  `po_CZberlian` text NOT NULL,
  `po_batupukulan` varchar(100) NOT NULL,
  `lasernama` text NOT NULL,
  `harga_awal` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pop_data`
--

INSERT INTO `pop_data` (`pop_id`, `pop_num`, `pop_customer`, `pop_nama`, `pop_notelp`, `pop_kota`, `pop_tglmsk`, `pop_jam`, `pop_jamsiap`, `pop_tglsls`, `total_berat`, `total_harga`, `pop_cabang`, `status`, `pop_diskon`, `pop_voucher`, `pop_keterangan`, `pop_bahan`, `pop_beratawal`, `pop_qty`, `krum`, `enamel`, `po_CZwarnatepper`, `po_keadaan`, `po_batukruman`, `po_CZberlian`, `po_batupukulan`, `lasernama`, `harga_awal`) VALUES
('1001-2019-PO-KRUM', 1001, '', 'Agus', '082113120808', 'Medan', '2019-08-18', '23:59', '13:20', '2019-08-23', 32, 36000, 'Surya Sumatera Cabang Sikambing', 1, 6500, 10000, 'asdasd', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1002-2019-PO-KRUM', 1002, '', 'Agus GG', '082113120808', 'Medan', '2019-08-27', '04:09', '', '2019-08-28', 428, 81000, 'Surya Sumatera Cabang Sikambing', 1, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1003-2019-PO-KRUM', 1003, '', 'Agus Awwab', '082113120808', 'Medan', '2019-08-28', '12:30', '', '2019-08-30', 0, 0, 'Surya Sumatera Cabang Sikambing', 0, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1004-2019-PO-KRUM', 1004, '', 'Agus Awwab', '082113120808', 'Medan', '2019-08-28', '12:30', '', '2019-08-30', 0, 0, 'Surya Sumatera Cabang Sikambing', 0, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1005-2019-PO-KRUM', 1005, '', 'Agus Awwab', '082113120808', 'Medan', '2019-08-28', '12:30', '', '2019-08-30', 0, 0, 'Surya Sumatera Cabang Sikambing', 0, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1006-2019-PO-KRUM', 1006, '', 'Agus Awwab', '082113120808', 'Medan', '2019-08-28', '12:30', '23:54', '2019-08-30', 32, 245900, 'Surya Sumatera Cabang Sikambing', 3, 3400, 6700, 'dsf', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1007-2019-PO-KRUM', 1007, '', 'Surya Sumatera', '06188813114', 'Medan', '2019-08-27', '12:30', '', '2019-08-09', 0, 0, 'Surya Sumatera Cabang Sikambing', 1, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0),
('1008-2019-PO-KRUM', 1008, '', 'Agus Aww', '082113120808', 'Medan', '2019-09-02', '12:30', '', '2019-09-10', 0, 0, '---Pilih Cabang---', 0, 0, 0, '', '', 0, 0, '', '', '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pop_order_foto`
--

CREATE TABLE `pop_order_foto` (
  `id` bigint(110) NOT NULL,
  `po_kode` varchar(255) NOT NULL,
  `po_orderid` int(11) NOT NULL,
  `po_foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pop_order_foto`
--

INSERT INTO `pop_order_foto` (`id`, `po_kode`, `po_orderid`, `po_foto`) VALUES
(1, '1001-2019-PO-KRUM', 1, '13769-j.jpg'),
(2, '1006-2019-PO-KRUM', 3, '96097-ghost.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pop_order_jenis`
--

CREATE TABLE `pop_order_jenis` (
  `id` bigint(110) NOT NULL,
  `po_kode` varchar(255) NOT NULL,
  `po_orderid` int(11) NOT NULL,
  `po_jenis` varchar(255) NOT NULL,
  `po_jqty` int(11) NOT NULL DEFAULT '0',
  `po_aksesoris` varchar(255) NOT NULL,
  `po_jaks` int(11) NOT NULL DEFAULT '0',
  `po_jsat` varchar(255) NOT NULL,
  `po_asat` varchar(255) NOT NULL,
  `harga_akhir` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pop_order_jenis`
--

INSERT INTO `pop_order_jenis` (`id`, `po_kode`, `po_orderid`, `po_jenis`, `po_jqty`, `po_aksesoris`, `po_jaks`, `po_jsat`, `po_asat`, `harga_akhir`) VALUES
(1, '1001-2019-PO-KRUM', 1, 'Cincin Bayi', 3, 'mainan', 6, 'pcs', 'pasang', 36000),
(2, '1002-2019-PO-KRUM', 1, 'Cincin Bayi', 3, ' ', 0, 'pcs', ' ', 9000),
(3, '1002-2019-PO-KRUM', 8, 'Cincin Bayi', 3, ' ', 0, 'pcs', ' ', 12000),
(4, '1002-2019-PO-KRUM', 9, 'Cincin Bayi', 1, ' ', 0, 'pasang', ' ', 60000),
(5, '1006-2019-PO-KRUM', 3, 'Gelang Kaku', 3, ' ', 0, 'pcs', ' ', 128000),
(6, '1006-2019-PO-KRUM', 3, 'Cincin Bayi', 3, 'mainan', 6, 'pcs', 'pcs', 128000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pop_order_krum`
--

CREATE TABLE `pop_order_krum` (
  `id` bigint(110) NOT NULL,
  `po_kode` varchar(255) NOT NULL,
  `po_orderid` int(11) NOT NULL,
  `po_krum` varchar(255) NOT NULL,
  `po_bahan` varchar(255) NOT NULL,
  `po_beratawal` int(11) NOT NULL DEFAULT '0',
  `keterangan` text NOT NULL,
  `po_harga` int(11) NOT NULL,
  `po_harga_2` int(11) NOT NULL,
  `po_beratms` int(11) NOT NULL,
  `po_beratak` int(11) NOT NULL,
  `po_kadar` int(11) NOT NULL,
  `CZberlian` varchar(110) NOT NULL,
  `CZwtm` varchar(100) NOT NULL,
  `pasangCZb` int(11) NOT NULL,
  `pasangCZwtm` int(11) NOT NULL,
  `laser_nama` varchar(255) NOT NULL,
  `jenis_tulisan` varchar(255) NOT NULL,
  `tukangpoles` varchar(255) NOT NULL,
  `tukangkrum` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pop_order_krum`
--

INSERT INTO `pop_order_krum` (`id`, `po_kode`, `po_orderid`, `po_krum`, `po_bahan`, `po_beratawal`, `keterangan`, `po_harga`, `po_harga_2`, `po_beratms`, `po_beratak`, `po_kadar`, `CZberlian`, `CZwtm`, `pasangCZb`, `pasangCZwtm`, `laser_nama`, `jenis_tulisan`, `tukangpoles`, `tukangkrum`) VALUES
(1, '1001-2019-PO-KRUM', 1, 'Krum Merah Surabaya', '', 32, 'asd', 4000, 36000, 0, 0, 0, '', '', 0, 0, '', '', '', ''),
(2, '1002-2019-PO-KRUM', 1, 'Krum Kuning', '', 43, 'asd', 3000, 9000, 0, 0, 0, '', '', 0, 0, '', '', '', ''),
(9, '1002-2019-PO-KRUM', 8, 'Krum Putih', '', 365, 'asd', 4000, 12000, 0, 0, 0, '', '', 0, 0, '', '', '', ''),
(10, '1002-2019-PO-KRUM', 9, 'Krum Kuning', '', 20, 'asd', 3000, 60000, 0, 0, 0, '', '', 0, 0, '', '', '', ''),
(17, '1006-2019-PO-KRUM', 3, 'Krum Merah Surabaya', 'Perak', 32, 'as', 4000, 256000, 30, 28, 1, 'Lengkap', 'Tidak Lengkap', 2, 1, 'Yasin Awwab', 'sadasd', 'Mandala Muhammad', 'Mandala Muhammad');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos_data`
--

CREATE TABLE `pos_data` (
  `pop_id` varchar(255) NOT NULL,
  `pop_num` int(11) NOT NULL,
  `pop_customer` varchar(50) NOT NULL,
  `pop_nama` varchar(255) NOT NULL,
  `pop_notelp` varchar(100) NOT NULL,
  `pop_kota` varchar(255) NOT NULL,
  `pop_tglmsk` date NOT NULL,
  `pop_jam` varchar(100) NOT NULL,
  `pop_jamsiap` varchar(100) NOT NULL,
  `pop_tglsls` date NOT NULL,
  `total_berat` int(11) NOT NULL DEFAULT '0',
  `total_harga` int(11) NOT NULL DEFAULT '0',
  `pop_cabang` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `pop_diskon` int(11) NOT NULL DEFAULT '0',
  `pop_voucher` int(11) NOT NULL DEFAULT '0',
  `pop_keterangan` text NOT NULL,
  `pop_bahan` varchar(255) NOT NULL,
  `pop_beratawal` int(11) NOT NULL DEFAULT '0',
  `pop_qty` int(11) NOT NULL,
  `krum` varchar(100) NOT NULL,
  `enamel` varchar(100) NOT NULL,
  `po_CZwarnatepper` varchar(100) NOT NULL,
  `po_keadaan` varchar(100) NOT NULL,
  `po_batukruman` varchar(100) NOT NULL,
  `po_CZberlian` text NOT NULL,
  `po_batupukulan` varchar(100) NOT NULL,
  `lasernama` text NOT NULL,
  `harga_awal` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pos_data`
--

INSERT INTO `pos_data` (`pop_id`, `pop_num`, `pop_customer`, `pop_nama`, `pop_notelp`, `pop_kota`, `pop_tglmsk`, `pop_jam`, `pop_jamsiap`, `pop_tglsls`, `total_berat`, `total_harga`, `pop_cabang`, `status`, `pop_diskon`, `pop_voucher`, `pop_keterangan`, `pop_bahan`, `pop_beratawal`, `pop_qty`, `krum`, `enamel`, `po_CZwarnatepper`, `po_keadaan`, `po_batukruman`, `po_CZberlian`, `po_batupukulan`, `lasernama`, `harga_awal`) VALUES
('1001-2019-PO-SATUAN', 1001, 'Pribadi', 'Agus', '082113120808', 'Medan', '2019-08-18', '19:29', '12:45', '2019-08-18', 0, -52120, 'Surya Sumatera Cabang Sikambing', 3, 36786, 45334, 'd', 'Emas', 45, 2, 'Putih/Kuning/Merah Surabaya/Rosegold', 'Putih', 'Lengkap', 'Mulus', 'Tidak', 'Lengkap', 'Sangat Bagus', 'Delia & Agus', 30000),
('1002-2019-PO-SATUAN', 1002, 'Toko', 'Mandala Muhammad', '082113120808', 'Medan', '2019-08-14', '22:17', '12:45', '2019-08-21', 0, 1500, 'Surya Sumatera Cabang Sikambing', 4, 1000, 2500, 'asdasd', 'Perak', 158, 2, 'Doff Putih  (DOFF)', 'Putih', 'Tidak Lengkap', 'Serat Kasar', 'Tidak', 'Tidak Lengkap', 'Kurang', '', 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos_harga`
--

CREATE TABLE `pos_harga` (
  `po_kode` varchar(255) NOT NULL,
  `po_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos_order_foto`
--

CREATE TABLE `pos_order_foto` (
  `id` bigint(110) NOT NULL,
  `po_kode` varchar(255) NOT NULL,
  `po_foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pos_order_foto`
--

INSERT INTO `pos_order_foto` (`id`, `po_kode`, `po_foto`) VALUES
(6, '1001-2019-PO-SATUAN', '35210-er.jpg'),
(7, '1001-2019-PO-SATUAN', '48601-s.jpg'),
(8, '1002-2019-PO-SATUAN', '83944-capture.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos_order_jenis`
--

CREATE TABLE `pos_order_jenis` (
  `id` bigint(110) NOT NULL,
  `po_kode` varchar(255) NOT NULL,
  `po_jenis` varchar(255) NOT NULL,
  `po_jqty` int(11) NOT NULL DEFAULT '0',
  `po_aksesoris` varchar(255) NOT NULL,
  `po_jaks` int(11) NOT NULL DEFAULT '0',
  `po_jsat` varchar(255) NOT NULL,
  `po_asat` varchar(255) NOT NULL,
  `harga_akhir` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pos_order_jenis`
--

INSERT INTO `pos_order_jenis` (`id`, `po_kode`, `po_jenis`, `po_jqty`, `po_aksesoris`, `po_jaks`, `po_jsat`, `po_asat`, `harga_akhir`) VALUES
(3, '1001-2019-PO-SATUAN', 'Cincin Cowok', 3, 'lonceng', 1, 'pcs', 'pasang', 5000),
(4, '1002-2019-PO-SATUAN', 'Cincin Cowok', 3, 'rumbai', 1, 'pcs', 'pcs', 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `cabang` int(11) NOT NULL,
  `nik` bigint(30) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `notelp` varchar(25) NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `sales`
--

INSERT INTO `sales` (`id`, `foto`, `cabang`, `nik`, `nama`, `notelp`, `username`) VALUES
(4, '49007-contoh-pas-foto-sbmptn.png', 2, 19165132154612, 'Delia Citra Skolastika', '082113120808', 'delia028'),
(5, '93340-pas-foto-biru.jpg', 2, 98465423165, 'Mandala Muhammad', '082113120808', 'mandala23'),
(6, '80250-pas-foto-serdos-2009.jpg', 2, 945956165156, 'Mugito Suryani', '082113120808', 'mgtsry00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(1, 'svperadmin', 'galagates', 1),
(4, 'delia028', '123123', 3),
(5, 'mandala23', '321321', 2),
(6, 'mgtsry00', 'mgtsry00mgtsry00', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `warna_harga`
--

CREATE TABLE `warna_harga` (
  `id` int(11) NOT NULL,
  `warna` varchar(30) NOT NULL,
  `harga` int(11) NOT NULL DEFAULT '5000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `warna_harga`
--

INSERT INTO `warna_harga` (`id`, `warna`, `harga`) VALUES
(1, 'Putih', 5000),
(2, 'Kuning', 5000),
(3, 'Merah Surabaya', 5000),
(4, 'Rosegold', 5000),
(5, 'Poles', 5000),
(6, 'Doff Putih', 5000),
(7, 'Doff Kuning', 5000),
(8, 'Doff Merah Surabaya', 5000),
(9, 'Doff Rosegold', 5000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `harga_partai`
--
ALTER TABLE `harga_partai`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `harga_satuan`
--
ALTER TABLE `harga_satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jenis_bahan`
--
ALTER TABLE `jenis_bahan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_satuan`
--
ALTER TABLE `kategori_satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `lokasicabang`
--
ALTER TABLE `lokasicabang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pop_order_foto`
--
ALTER TABLE `pop_order_foto`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pop_order_jenis`
--
ALTER TABLE `pop_order_jenis`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pop_order_krum`
--
ALTER TABLE `pop_order_krum`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pos_order_foto`
--
ALTER TABLE `pos_order_foto`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pos_order_jenis`
--
ALTER TABLE `pos_order_jenis`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `warna_harga`
--
ALTER TABLE `warna_harga`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `harga_partai`
--
ALTER TABLE `harga_partai`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `harga_satuan`
--
ALTER TABLE `harga_satuan`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `jenis_bahan`
--
ALTER TABLE `jenis_bahan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategori_satuan`
--
ALTER TABLE `kategori_satuan`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `lokasicabang`
--
ALTER TABLE `lokasicabang`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pop_order_foto`
--
ALTER TABLE `pop_order_foto`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pop_order_jenis`
--
ALTER TABLE `pop_order_jenis`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pop_order_krum`
--
ALTER TABLE `pop_order_krum`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `pos_order_foto`
--
ALTER TABLE `pos_order_foto`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `pos_order_jenis`
--
ALTER TABLE `pos_order_jenis`
  MODIFY `id` bigint(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `warna_harga`
--
ALTER TABLE `warna_harga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

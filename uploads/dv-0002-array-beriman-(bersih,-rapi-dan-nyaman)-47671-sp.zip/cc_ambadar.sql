-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Sep 2019 pada 14.50
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc_ambadar`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `baru_booster`
--

CREATE TABLE `baru_booster` (
  `nopeg` varchar(100) NOT NULL,
  `nama_booster` varchar(200) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `direktorat` varchar(100) NOT NULL,
  `aktif_start` date DEFAULT NULL,
  `aktif_end` date DEFAULT NULL,
  `status_aktif` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(299) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `baru_tim_implementasi_budaya`
--

CREATE TABLE `baru_tim_implementasi_budaya` (
  `nopeg` varchar(255) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `posisi` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `direktorat` varchar(255) NOT NULL,
  `aktif_start` date NOT NULL,
  `aktif_end` date NOT NULL,
  `status_aktif` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `baru_warrior`
--

CREATE TABLE `baru_warrior` (
  `nopeg` varchar(100) NOT NULL,
  `nama_warrior` varchar(200) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `direktorat` varchar(100) NOT NULL,
  `aktif_start` date DEFAULT NULL,
  `aktif_end` date DEFAULT NULL,
  `status_aktif` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(299) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bobot`
--

CREATE TABLE `bobot` (
  `id` int(11) NOT NULL DEFAULT '0',
  `bobot1` int(11) NOT NULL,
  `bobot2` int(11) NOT NULL,
  `bobot3` int(11) NOT NULL,
  `bobot4` int(11) NOT NULL,
  `bobot5` int(11) NOT NULL,
  `bobot6` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bobot`
--

INSERT INTO `bobot` (`id`, `bobot1`, `bobot2`, `bobot3`, `bobot4`, `bobot5`, `bobot6`) VALUES
(0, 10, 10, 35, 15, 15, 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ca_performance_upload`
--

CREATE TABLE `ca_performance_upload` (
  `id_upload` int(11) NOT NULL,
  `id_ca` int(11) NOT NULL,
  `unit_name` varchar(255) NOT NULL,
  `kode` varchar(11) NOT NULL,
  `last_modified` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ca_performance_upload`
--

INSERT INTO `ca_performance_upload` (`id_upload`, `id_ca`, `unit_name`, `kode`, `last_modified`) VALUES
(0, 7, 'Column3', 'sdf', ' '),
(1, 1, 'GM-0001', 'GM', ''),
(2, 1, 'MHF-0001', 'MHF', ''),
(3, 1, 'MHF-0002', 'MHF', ''),
(4, 1, 'MHF-0003', 'MHF', ''),
(5, 1, 'MIG-0001', 'MIG', ''),
(6, 1, 'MIG-0002', 'MIG', ''),
(7, 1, 'MLM-0001', 'MLM', ''),
(8, 1, 'MLM-0002', 'MLM', ''),
(9, 1, 'MP-0001', 'MP', ''),
(10, 1, 'MP-0002', 'MP', ''),
(11, 1, 'MP-0003', 'MP', ''),
(12, 1, 'MP-0004', 'MP', ''),
(13, 1, 'MHDC-0001', 'MHDC', ''),
(15, 1, 'MHDC-0002', 'MHDC', ''),
(16, 1, 'MHDC-0003', 'MHDC', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ca_user`
--

CREATE TABLE `ca_user` (
  `id_ca` int(10) NOT NULL,
  `ca_nopeg` varchar(250) NOT NULL,
  `ca_password` varchar(250) NOT NULL,
  `status` int(10) DEFAULT '1',
  `last_modified` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program`
--

CREATE TABLE `cc_program` (
  `cc_id` int(10) NOT NULL,
  `cc_detail` varchar(100) NOT NULL,
  `cc_desc` longtext NOT NULL,
  `cc_tujuan` longtext NOT NULL,
  `cc_time` int(10) NOT NULL,
  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL DEFAULT 'Disable',
  `start_month` date NOT NULL,
  `end_month` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cc_program`
--

INSERT INTO `cc_program` (`cc_id`, `cc_detail`, `cc_desc`, `cc_tujuan`, `cc_time`, `last_modified`, `status`, `start_month`, `end_month`) VALUES
(1, 'Harmonisasi Culture', 'lorem ipsum dolor amet lorem ipsum dolor amet, lorem ipsum dolor ametlorem ipsum dolor amet, lorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor amet', 'lorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor amet, lorem ipsum dolor amet', 12, '2019-02-27 05:12:37', 'Default', '2019-01-10', '2020-01-10'),
(2, 'Evaluasi Perkembangan Culture', 'lorem ipsum dolor amet lorem ipsum dolor amet, lorem ipsum dolor ametlorem ipsum dolor amet, lorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor amet', 'lorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor amet, lorem ipsum dolor amet', 13, '2019-02-27 05:12:37', 'Default', '2019-07-12', '2020-07-21'),
(3, 'English Day', 'lorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor ametlorem ipsum dolor amet', 'lorem ipsum dolor amet lorem ipsum dolor amet lorem ipsum dolor amet  em ipsum dolor amet em ipsum dolor amet em ipsum dolor amet ', 36, '2019-02-28 01:16:29', 'Default', '2019-02-13', '2022-02-06'),
(7, 'Culture Holiday', 'lorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amer', ' lorem ipsum dolor amer lorem ipsum dolor amerlorem ipsum dolor amer lorem ipsum dolor amer lorem ipsum dolor amer lorem ipsum dolor amer lorem ipsum dolor amer ', 36, '2019-02-28 01:44:48', 'Default', '2020-02-08', '2023-01-31'),
(8, 'Art Culture International', 'lorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amer', 'lorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amer', 109, '2019-02-28 01:45:12', 'Default', '2019-02-22', '2028-02-13'),
(9, 'Culturion Centurion Amakamekame', 'lorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amer', 'lorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum dolor amerlorem ipsum  ipsum dolor amerlorem ipsum', 12, '2019-02-28 01:45:42', 'Default', '2019-02-09', '2020-02-14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program_eval`
--

CREATE TABLE `cc_program_eval` (
  `input_id` int(10) NOT NULL,
  `input_user_c` varchar(225) NOT NULL,
  `input_detail_c` varchar(255) NOT NULL,
  `input_realisasi` varchar(255) NOT NULL,
  `input_realisasi_` varchar(255) NOT NULL,
  `input_metodologi` varchar(255) NOT NULL,
  `input_reinforcement_positif` varchar(255) NOT NULL,
  `input_reinforcement_negatif` varchar(255) NOT NULL,
  `input_attach` varchar(255) NOT NULL,
  `input_gap` varchar(255) NOT NULL,
  `input_tanggal` int(10) NOT NULL,
  `input_bulan` varchar(255) NOT NULL,
  `last_modified_c` varchar(255) NOT NULL,
  `input_status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program_feedback`
--

CREATE TABLE `cc_program_feedback` (
  `fb_id` int(100) NOT NULL,
  `fb_sender` varchar(225) NOT NULL,
  `fb_recipient` varchar(225) NOT NULL,
  `fb_content` longtext NOT NULL,
  `fb_program` varchar(225) NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `feedback_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program_input`
--

CREATE TABLE `cc_program_input` (
  `_input_id` int(10) NOT NULL,
  `input_user` varchar(255) NOT NULL,
  `input_program_id` int(11) NOT NULL,
  `input_detail` varchar(255) NOT NULL,
  `input_target` varchar(255) NOT NULL,
  `input_satuan` varchar(255) NOT NULL,
  `last_modified` varchar(255) NOT NULL,
  `_input_status` int(10) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program_nilai`
--

CREATE TABLE `cc_program_nilai` (
  `cc_unit` varchar(20) NOT NULL,
  `cc_dir` varchar(300) NOT NULL,
  `cc_lokasi` varchar(20) NOT NULL,
  `score` int(11) NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cc_program_nilai`
--

INSERT INTO `cc_program_nilai` (`cc_unit`, `cc_dir`, `cc_lokasi`, `score`, `last_modified`) VALUES
('USUWK', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USKJY', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USJND', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USUTG', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USPGT', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USDRM', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USTBR', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USWYG', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USINJ', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USPJK', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USTGL', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USPGS', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USKBT', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USROR', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USPST', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USLDK', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USKRA', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USPDG', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('USMNY', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('BYGTG', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BYGMB', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BYPSG', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BYRGJ', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BYGLN', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BYWGS', 'CABANG BANYUWANGI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBTGL', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBKLS', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBBLG', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBKCG', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBRBP', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JBAMB', 'CABANG JEMBER', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MLLWG', 'CABANG MALANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MLTMG', 'CABANG MALANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MLKRP', 'CABANG MALANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MDCRB', 'CABANG MADIUN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MDDLP', 'CABANG MADIUN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MDUMR', 'CABANG MADIUN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MDJWN', 'CABANG MADIUN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MDSRD', 'CABANG MADIUN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDGGL', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDWTS', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDNDH', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDPGU', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDMRC', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDRGR', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KDGRH', 'CABANG KEDIRI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PKWRU', 'CABANG PAMEKASAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PKGLS', 'CABANG PAMEKASAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BGSMB', 'CABANG BOJONEGORO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BGKLD', 'CABANG BOJONEGORO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BGKDA', 'CABANG BOJONEGORO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BGPDG', 'CABANG BOJONEGORO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LMPSI', 'CABANG LUMAJANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LMSKD', 'CABANG LUMAJANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LMPRJ', 'CABANG LUMAJANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LMYSW', 'CABANG LUMAJANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGWKK', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGPRN', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGKRJ', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGKDG', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGKND', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGMTG', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGNMB', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NGGNG', 'CABANG NGAWI', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JOMJG', 'CABANG JOMBANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JOPRK', 'CABANG JOMBANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JOPSO', 'CABANG JOMBANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KRMRN', 'CABANG KRAKSAAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KRDRG', 'CABANG KRAKSAAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PBLCS', 'CABANG PROBOLINGGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PBTGS', 'CABANG PROBOLINGGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PBPSB', 'CABANG PROBOLINGGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BLWLG', 'CABANG BLITAR', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BLSGT', 'CABANG BLITAR', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BLKDM', 'CABANG BLITAR', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BLKGR', 'CABANG BLITAR', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BLLDY', 'CABANG BLITAR', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBNNT', 'CABANG TULUNGAGUNG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBBDG', 'CABANG TULUNGAGUNG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBKAU', 'CABANG TULUNGAGUNG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBCMD', 'CABANG TULUNGAGUNG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBJTR', 'CABANG TUBAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBRGL', 'CABANG TUBAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBKRK', 'CABANG TUBAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBBCR', 'CABANG TUBAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TBWDG', 'CABANG TUBAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MJMJS', 'CABANG MOJOKERTO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MJJNG', 'CABANG MOJOKERTO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MJSOK', 'CABANG MOJOKERTO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SPPRG', 'CABANG SUMENEP', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SGKTP', 'CABANG SAMPANG', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BKKML', 'CABANG BANGKALAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BKBLG', 'CABANG BANGKALAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BKKWY', 'CABANG BANGKALAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRPDN', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRBGL', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRPRW', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRKJP', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRNLG', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRNPK', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PRWGD', 'CABANG PASURUAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NJKTS', 'CABANG NGANJUK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NJTJA', 'CABANG NGANJUK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NJBRB', 'CABANG NGANJUK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('NJRJS', 'CABANG NGANJUK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TGWTM', 'CABANG TRENGGALEK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TGPNG', 'CABANG TRENGGALEK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('TGKRG', 'CABANG TRENGGALEK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PGSMR', 'CABANG PONOROGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PGJTS', 'CABANG PONOROGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PGPLG', 'CABANG PONOROGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PGBLG', 'CABANG PONOROGO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PCNDJ', 'CABANG PACITAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PCARJ', 'CABANG PACITAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PCPNG', 'CABANG PACITAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('GRSDY', 'CABANG GRESIK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('GRCRM', 'CABANG GRESIK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('GRDRY', 'CABANG GRESIK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('GRBPG', 'CABANG GRESIK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('GRMGT', 'CABANG GRESIK', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJTMN', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJKRN', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJTLG', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJPSA', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJWRU', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJGDG', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJPRG', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SJPRB', 'CABANG SIDOARJO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LGBBT', 'CABANG LAMONGAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LGBDG', 'CABANG LAMONGAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LGSGO', 'CABANG LAMONGAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LGKGG', 'CABANG LAMONGAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('LGMTP', 'CABANG LAMONGAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('STBSK', 'CABANG SITUBONDO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('STAMB', 'CABANG SITUBONDO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BDPJK', 'CABANG BONDOWOSO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BDWNS', 'CABANG BONDOWOSO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BDMES', 'CABANG BONDOWOSO', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MGBRT', 'CABANG MAGETAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MGGGR', 'CABANG MAGETAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MGPLS', 'CABANG MAGETAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('MGMSP', 'CABANG MAGETAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SSRKT', 'CABANG DR. SOETOMO SURABAYA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SSMLY', 'CABANG DR. SOETOMO SURABAYA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SRRJW', 'CABANG PERAK SURABAYA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SRBNW', 'CABANG PERAK SURABAYA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SRMNK', 'CABANG PERAK SURABAYA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKWMG', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKMGD', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKBKS', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKDPK', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKKGD', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('JKTGR', 'CABANG JAKARTA', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BTBMJ', 'CABANG BATU', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PEKDG', 'CABANG PARE', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('PEKDK', 'CABANG PARE', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KJDNM', 'CABANG KEPANJEN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KJSBP', 'CABANG KEPANJEN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KJDPT', 'CABANG KEPANJEN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('KJTRN', 'CABANG KEPANJEN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('SYSMP', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYMMY', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYWYG', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYMRR', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYBLT', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYPBG', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYLMG', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYGTG', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('SYJBG', 'CABANG SYARIAH', 'CBGSYRH', 0, '0000-00-00 00:00:00'),
('USHMS', 'CABANG UTAMA SURABAYA', 'CBUTSBY', 0, '0000-00-00 00:00:00'),
('KGEAN', 'CABANG KANGEAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BWEAN', 'CABANG BAWEAN', 'CBPMBNT', 0, '0000-00-00 00:00:00'),
('BATAM', 'CABANG BATAM', 'CBPMBNT', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cc_program_overall`
--

CREATE TABLE `cc_program_overall` (
  `cc_unit` varchar(20) NOT NULL,
  `cc_dir` varchar(300) NOT NULL,
  `cc_lokasi` varchar(20) NOT NULL,
  `progress` int(11) NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cc_program_overall`
--

INSERT INTO `cc_program_overall` (`cc_unit`, `cc_dir`, `cc_lokasi`, `progress`, `last_modified`) VALUES
('GM-0001', 'GENERAL MANAGER', 'GM', 0, '0000-00-00 00:00:00'),
('MHF-0001', 'MANAGER HR & FINANCE', 'MHF', 0, '0000-00-00 00:00:00'),
('MHF-0002', 'MANAGER HR & FINANCE', 'MHF', 0, '0000-00-00 00:00:00'),
('MHF-0003', 'MANAGER HR & FINANCE', 'MHF', 0, '0000-00-00 00:00:00'),
('MIG-0001', 'MANAGER IT & GA', 'MIG', 0, '0000-00-00 00:00:00'),
('MIG-0002', 'MANAGER IT & GA', 'MIG', 0, '0000-00-00 00:00:00'),
('MLM-0001', 'MANAGER LEGAL & MARKETING', 'MLM', 0, '0000-00-00 00:00:00'),
('MLM-0002', 'MANAGER LEGAL & MARKETING', 'MLM', 0, '0000-00-00 00:00:00'),
('MP-0001', 'MANAGER PATEN', 'MP', 0, '0000-00-00 00:00:00'),
('MP-0002', 'MANAGER PATEN', 'MP', 0, '0000-00-00 00:00:00'),
('MP-0003', 'MANAGER PATEN', 'MP', 0, '0000-00-00 00:00:00'),
('MP-0004', 'MANAGER PATEN', 'MP', 0, '0000-00-00 00:00:00'),
('MHDC-0001', 'MANAGER MDHC', 'MHDC', 0, '0000-00-00 00:00:00'),
('MHDC-0002', 'MANAGER MDHC', 'MHDC', 0, '0000-00-00 00:00:00'),
('MHDC-0003', 'MANAGER MDHC', 'MHDC', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `direktorat`
--

CREATE TABLE `direktorat` (
  `dir_id` int(11) NOT NULL,
  `dir_code` varchar(100) NOT NULL,
  `status` int(11) DEFAULT '1',
  `last_modified` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `direktorat`
--

INSERT INTO `direktorat` (`dir_id`, `dir_code`, `status`, `last_modified`) VALUES
(1, 'CABANG UTAMA SURABAYA', 12, ' '),
(2, 'CABANG BANYUWANGI', 1, ''),
(3, 'CABANG JEMBER', 1, ''),
(4, 'CABANG MALANG', 1, ''),
(5, 'CABANG MADIUN', 1, ''),
(6, 'CABANG KEDIRI', 1, ''),
(7, 'CABANG PAMEKASAN', 1, ''),
(8, 'CABANG BOJONEGORO', 1, ''),
(9, 'CABANG LUMAJANG', 1, ''),
(10, 'CABANG NGAWI', 1, ''),
(11, 'CABANG JOMBANG', 1, ''),
(12, 'CABANG KRAKSAAN', 1, ''),
(13, 'CABANG PROBOLINGGO', 1, ''),
(14, 'CABANG BLITAR', 1, ''),
(15, 'CABANG TULUNGAGUNG', 1, ''),
(16, 'CABANG TUBAN', 1, ''),
(17, 'CABANG MOJOKERTO', 1, ''),
(18, 'CABANG SUMENEP', 1, ''),
(19, 'CABANG SAMPANG', 1, ''),
(20, 'CABANG BANGKALAN', 1, ''),
(21, 'CABANG PASURUAN', 1, ''),
(22, 'CABANG NGANJUK', 1, ''),
(23, 'CABANG TRENGGALEK', 1, ''),
(24, 'CABANG PONOROGO', 1, ''),
(25, 'CABANG PACITAN', 1, ''),
(26, 'CABANG GRESIK', 1, ''),
(27, 'CABANG SIDOARJO', 1, ''),
(28, 'CABANG LAMONGAN', 1, ''),
(29, 'CABANG SITUBONDO', 1, ''),
(30, 'CABANG BONDOWOSO', 1, ''),
(31, 'CABANG MAGETAN', 1, ''),
(32, 'CABANG DR. SOETOMO SURABAYA', 1, ''),
(33, 'CABANG PERAK SURABAYA', 1, ''),
(34, 'CABANG JAKARTA', 1, ''),
(35, 'CABANG BATU', 1, ''),
(36, 'CABANG PARE', 1, ''),
(37, 'CABANG KEPANJEN', 1, ''),
(38, 'CABANG SYARIAH', 1, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `employee`
--

CREATE TABLE `employee` (
  `iduser` int(11) NOT NULL,
  `NIP` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `sitacode` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `evidence`
--

CREATE TABLE `evidence` (
  `id_evidence` int(11) NOT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `bukti` varchar(100) DEFAULT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `total_score`
--

CREATE TABLE `total_score` (
  `id_unit` int(7) DEFAULT NULL,
  `kode_unit` varchar(9) DEFAULT NULL,
  `nama_unit` varchar(50) DEFAULT NULL,
  `kode_dir` int(8) DEFAULT NULL,
  `nama_dir` varchar(27) DEFAULT NULL,
  `nilai_bobot1` int(12) DEFAULT NULL,
  `nilai_bobot2` int(12) DEFAULT NULL,
  `nilai_bobot3` int(12) DEFAULT NULL,
  `nilai_bobot4` int(12) DEFAULT NULL,
  `nilai_bobot5` int(12) DEFAULT NULL,
  `nilai_bobot6` int(12) DEFAULT NULL,
  `total_score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data untuk tabel `total_score`
--

INSERT INTO `total_score` (`id_unit`, `kode_unit`, `nama_unit`, `kode_dir`, `nama_dir`, `nilai_bobot1`, `nilai_bobot2`, `nilai_bobot3`, `nilai_bobot4`, `nilai_bobot5`, `nilai_bobot6`, `total_score`) VALUES
(1, 'GM-0001', 'GENERAL MANAGER', 1, 'GENERAL MANAGER', 0, 0, 0, 0, 0, 0, 0),
(2, 'MHF-0001', 'ACCOUNT & FAX', 2, 'MANAGER HR & FINANCE', 0, 0, 0, 0, 0, 0, 0),
(3, 'MHF-0002', 'FINANCE', 2, 'MANAGER HR & FINANCE', 0, 0, 0, 0, 0, 0, 0),
(4, 'MHF-0003', 'HR', 2, 'MANAGER HR & FINANCE', 0, 0, 0, 0, 0, 0, 0),
(5, 'MIG-0001', 'IT', 3, 'MANAGER IT & GA', 0, 0, 0, 0, 0, 0, 0),
(6, 'MIG-0002', 'GENERAL AFFAIR', 3, 'MANAGER IT & GA', 0, 0, 0, 0, 0, 0, 0),
(7, 'MLM-0001', 'MARKETING', 4, 'MANAGER LEGAL & MARKETING', 0, 0, 0, 0, 0, 0, 0),
(8, 'MLM-0002', 'LEGAL', 4, 'MANAGER LEGAL & MARKETING', 0, 0, 0, 0, 0, 0, 0),
(9, 'MP-0001', 'ORDER & PERMOHONAN PATEN', 5, 'MANAGER PATEN', 0, 0, 0, 0, 0, 0, 0),
(10, 'MP-0002', 'MAINTENANCE PATEN', 5, 'MANAGER PATEN', 0, 0, 0, 0, 0, 0, 0),
(11, 'MP-0003', 'SUBSTANTIVE & SERTIFIKAT  PATEN', 5, 'MANAGER PATEN', 0, 0, 0, 0, 0, 0, 0),
(12, 'MP-0004', 'CORPORATE SECRETARY', 5, 'MANAGER PATEN', 0, 0, 0, 0, 0, 0, 0),
(13, 'MHDC-0001', 'ORDER & PERMOHONAN MDHC', 6, 'MANAGER MDHC', 0, 0, 0, 0, 0, 0, 0),
(14, 'MHDC-0002', 'MAINTENANCE MDHC', 6, 'MANAGER MDHC', 0, 0, 0, 0, 0, 0, 0),
(15, 'MHDC-0003', 'SUBSTANTIVE & SERTIFIKAT MDHC', 6, 'MANAGER MDHC', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL,
  `nama_unit` varchar(255) NOT NULL,
  `kode_unit` varchar(100) NOT NULL,
  `kode_dir` varchar(100) NOT NULL,
  `kode_ca` varchar(100) NOT NULL,
  `kode_lokasi` varchar(255) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `unit`
--

INSERT INTO `unit` (`unit_id`, `nama_unit`, `kode_unit`, `kode_dir`, `kode_ca`, `kode_lokasi`, `last_update`) VALUES
(1, 'GENERAL MANAGER', 'GM-0001', 'GENERAL MANAGER', '1', 'GM', '0000-00-00 00:00:00'),
(2, 'ACCOUNT & FAX', 'MHF-0001', 'MANAGER HR & FINANCE', '2', 'MHF', '0000-00-00 00:00:00'),
(3, 'FINANCE', 'MHF-0002', 'MANAGER HR & FINANCE', '2', 'MHF', '0000-00-00 00:00:00'),
(4, 'HR', 'MHF-0003', 'MANAGER HR & FINANCE', '2', 'MHF', '0000-00-00 00:00:00'),
(5, 'IT', 'MIG-0001', 'MANAGER IT & GA', '3', 'MIG', '0000-00-00 00:00:00'),
(6, 'GENERAL AFFAIR', 'MIG-0002', 'MANAGER IT & GA', '3', 'MIG', '0000-00-00 00:00:00'),
(7, 'MARKETING', 'MLM-0001', 'MANAGER LEGAL & MARKETING', '4', 'MLM', '0000-00-00 00:00:00'),
(8, 'LEGAL', 'MLM-0002', 'MANAGER LEGAL & MARKETING', '4', 'MLM', '0000-00-00 00:00:00'),
(9, 'ORDER & PERMOHONAN PATEN', 'MP-0001', 'MANAGER PATEN', '5', 'MP', '0000-00-00 00:00:00'),
(10, 'MAINTENANCE PATEN', 'MP-0002', 'MANAGER PATEN', '5', 'MP', '0000-00-00 00:00:00'),
(11, 'SUBSTANTIVE & SERTIFIKAT  PATEN', 'MP-0003', 'MANAGER PATEN', '5', 'MP', '0000-00-00 00:00:00'),
(12, 'CORPORATE SECRETARY', 'MP-0004', 'MANAGER PATEN', '5', 'MP', '0000-00-00 00:00:00'),
(13, 'ORDER & PERMOHONAN MDHC', 'MHDC-0001', 'MANAGER MDHC', '6', 'MHDC', '0000-00-00 00:00:00'),
(14, 'MAINTENANCE MDHC', 'MHDC-0002', 'MANAGER MDHC', '6', 'MHDC', '0000-00-00 00:00:00'),
(15, 'SUBSTANTIVE & SERTIFIKAT MDHC', 'MHDC-0003', 'MANAGER MDHC', '6', 'MHDC', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`iduser`, `username`, `password`, `role`) VALUES
(1, 'GM-0001', 'GM-0001', 1),
(2, 'MHF-0001', 'MHF-0001', 1),
(3, 'MHF-0002', 'MHF-0002', 1),
(4, 'MHF-0003', 'MHF-0003', 1),
(5, 'MIG-0001', 'MIG-0001', 1),
(6, 'MIG-0002', 'MIG-0002', 1),
(7, 'MLM-0001', 'MLM-0001', 1),
(8, 'MLM-0002', 'MLM-0002', 1),
(9, 'MP-0001', 'MP-0001', 1),
(10, 'MP-0002', 'MP-0002', 1),
(11, 'MP-0003', 'MP-0003', 1),
(12, 'MP-0004', 'MP-0004', 1),
(13, 'MHDC-0001', 'MHDC-0001', 1),
(14, 'MHDC-0002', 'MHDC-0002', 1),
(15, 'MHDC-0003', 'MHDC-0003', 1),
(999, 'Admin-Am', 'admin', -1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `baru_booster`
--
ALTER TABLE `baru_booster`
  ADD PRIMARY KEY (`nopeg`);

--
-- Indeks untuk tabel `baru_tim_implementasi_budaya`
--
ALTER TABLE `baru_tim_implementasi_budaya`
  ADD PRIMARY KEY (`nopeg`);

--
-- Indeks untuk tabel `baru_warrior`
--
ALTER TABLE `baru_warrior`
  ADD PRIMARY KEY (`nopeg`);

--
-- Indeks untuk tabel `bobot`
--
ALTER TABLE `bobot`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ca_performance_upload`
--
ALTER TABLE `ca_performance_upload`
  ADD PRIMARY KEY (`id_upload`);

--
-- Indeks untuk tabel `cc_program`
--
ALTER TABLE `cc_program`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indeks untuk tabel `cc_program_eval`
--
ALTER TABLE `cc_program_eval`
  ADD PRIMARY KEY (`input_id`);

--
-- Indeks untuk tabel `cc_program_feedback`
--
ALTER TABLE `cc_program_feedback`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indeks untuk tabel `cc_program_input`
--
ALTER TABLE `cc_program_input`
  ADD PRIMARY KEY (`_input_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `cc_program`
--
ALTER TABLE `cc_program`
  MODIFY `cc_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `cc_program_eval`
--
ALTER TABLE `cc_program_eval`
  MODIFY `input_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `cc_program_input`
--
ALTER TABLE `cc_program_input`
  MODIFY `_input_id` int(10) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Rancang;

import java.io.Serializable;
/**
 *
 * @author ACER
 */
class DataTerima implements Serializable {
    private String nrp;
    private String mahasiswa;
    private String id;
    private String status;
    
    DataTerima (String nrp, String mahasiswa, String id ,String status) {
        this.id = id;
        this.mahasiswa= mahasiswa;
        this.nrp = nrp;
        this.status = status;
    }

    public String getNrp() {
        return nrp;
    }

    public void setNrp(String nrp) {
        this.nrp = nrp;
    }

    public String getMahasiswa() {
        return mahasiswa;
    }

    public void setMahasiswa(String mahasiswa) {
        this.mahasiswa = mahasiswa;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}



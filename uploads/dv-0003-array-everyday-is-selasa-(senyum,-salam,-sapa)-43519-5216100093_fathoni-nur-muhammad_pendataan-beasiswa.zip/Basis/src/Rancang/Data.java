/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Rancang;

import java.io.Serializable;
/**
 *
 * @author ACER
 */
class Data implements Serializable {
    private String id;
    private String nama;
    private String asal;
    private String tanggal;
    private String daftar;
    private String terima;
    
    
    Data (String id, String nama, String asal ,String tanggal, String daftar, String terima) {
        this.id = id;
        this.nama= nama;
        this.asal = asal;
        this.tanggal = tanggal;
        this.daftar = daftar;
        this.terima = terima;
    }
     
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAsal() {
        return asal;
    }

    
    public void setAsal(String asal) {
        this.asal = asal;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getDaftar() {
        return daftar;
    }

    public void setDaftar(String daftar) {
        this.daftar = daftar;
    }

    public String getTerima() {
        return terima;
    }

    public void setTerima(String terima) {
        this.terima = terima;
    }
    
}
